NMAP-GUI
========

A modern, easy browser interface for the nmap network scanner. Pick a target,
pick a scan type, press Start, and see which devices are on your network, which
ports are open and what changed since last time.

[Screenshot: nmap-gui: choose a target and one of ten ready-made scan types –
docs/screenshots/new-scan.png]

nmap-gui runs a small program on your own computer and shows its interface in
your web browser. It starts nmap (https://nmap.org) for you, turns nmap's
results into tidy cards, tables and a network map, keeps a history of every
scan, and can tell you what changed between two scans, with a ready-to-send
email note for the people who need to know.

  | Only scan networks and computers that you own or have permission to scan.

FEATURES
--------

  - Ten ready-made scan types, from a quick device search to service versions,
    scripts, OS detection and UDP. The exact nmap command is shown before you
    start.
  - Live progress: devices and open ports appear while the scan runs; stop it at
    any time.
  - Clear results: a card for every device (hostname, MAC address, vendor, OS
    guess, open ports and software versions), a port table you can filter, and
    nmap's raw output.
  - Network map: every device around the scanner, coloured by how many ports are
    open. Click a device to see its details.
  - History: every scan is saved, and stays after you close the program.
  - Changes: compare a scan with an earlier one: new devices, devices not seen,
    ports that opened or closed, changed software, a device that moved to
    another IP address, or a different device on a known address.
  - Email note: a ready-to-send message about the changes, from your own
    template, with Send email, Copy text and Download report.
  - Light and dark theme, works in narrow windows too.
  - No extra packages: only Python 3 and nmap.

[Screenshot: Results in the dark theme: one card per device –
docs/screenshots/results-dark.png]

INSTALL
-------

nmap-gui needs Python 3.8 or newer and nmap (sudo dnf install nmap on Fedora,
sudo apt install nmap on Debian/Ubuntu).

Fedora (RPM)
~~~~~~~~~~~~

Download nmap-gui-1.0.0-1.fc45.noarch.rpm from the Releases page
(https://github.com/agent-denis/nmap-gui/releases) and install it:

    sudo dnf install ./nmap-gui-1.0.0-1.fc45.noarch.rpm

The same RPM works on Fedora 44, 45 and newer. dnf installs nmap too if it is
missing.

Any Linux, for your user only
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    git clone https://github.com/agent-denis/nmap-gui.git
    cd nmap-gui
    ./install.sh

install.sh needs no root rights. It copies nmap-gui to ~/.local/share/nmap-
gui/app, adds the nmap-gui command to ~/.local/bin and adds nmap-gui to your app
menu. Run it again to upgrade. Remove it with ./uninstall.sh (add --purge to
also delete your scan history and settings).

Without installing
~~~~~~~~~~~~~~~~~~

    ./nmap-gui                 # opens http://127.0.0.1:8642 in your browser; Ctrl+C stops it

USING NMAP-GUI
--------------

Open nmap-gui from your app menu. It starts in the background and opens in your
browser. Clicking the icon again just opens the page again.

  1. Type a target: one address (192.168.1.10), a whole home network
     (192.168.1.0/24), a range (10.0.0.1-50) or a name (scanme.nmap.org, nmap's
     own test server).
  2. Pick a scan type and press Start scan.
  3. Watch the results arrive. The tabs show Hosts, Ports, Network map, Changes
     and nmap's Raw output.

nmap-gui stops by itself 10 minutes after you close the last page (unless a scan
is running). You can also stop it with the ⏻ button on the page, with Stop nmap-
gui in the icon's right-click menu, or with nmap-gui --stop.

  - nmap-gui: Start and open the browser
  - nmap-gui --port 9000: Use another port (default 8642)
  - nmap-gui --no-browser: Don't open the browser
  - nmap-gui --stop: Stop a running nmap-gui
  - sudo nmap-gui: Admin mode: unlocks OS detection, UDP and Intense scans

[Screenshot: Network map: devices around the scanner, coloured by open ports –
docs/screenshots/network-map.png]

SCAN TYPES
----------

  Scan type                 nmap options              Needs sudo
  -----------------------   -----------------------   ----------
  Find devices              -sn
  Quick scan                -T4 -F
  Quick scan, no ping       -T4 -F -Pn
  Regular scan              (nmap's defaults)
  Service versions          -T4 -sV
  Versions + safe scripts   -T4 -sV -sC
  All TCP ports             -T4 -p-
  OS detection              -T4 -O --osscan-guess     yes
  UDP scan                  -T4 -sU --top-ports 100   yes
  Intense scan              -T4 -A                    yes

nmap-gui always adds -v (to show progress) and saves nmap's XML report. Scan
types that need sudo are greyed out unless nmap-gui was started with sudo nmap-
gui.

COMPARING SCANS AND THE EMAIL NOTE
----------------------------------

Open a scan and choose the Changes tab. nmap-gui compares it with the previous
scan of the same target (or any scan you pick) and lists what changed.

Below the list is an email note, filled in from a template:

  | We noticed differences on 192.168.1.0/24 between the scan on Mon, 16 Nov
  | 2026, 13:32 and the scan
  | on Tue, 17 Nov 2026, 13:02. Summary: 2 new devices, 1 device not seen, port
  | changes on 1 device. …

  - Send email opens your email program with recipient, subject and text filled
    in; you press Send there. nmap-gui never sends email itself.
  - Copy text copies the note, for webmail.
  - Download report saves a tidy HTML report to attach.
  - Edit template changes the wording and the default recipients. Words in curly
    brackets such as {new_devices} or {old_time} are filled in automatically.

[Screenshot: Changes tab: new devices, devices not seen and port changes, with
the email note – docs/screenshots/changes.png]

PRIVACY AND SAFETY
------------------

  - nmap-gui collects nothing and sends nothing anywhere. It has no accounts, no
    analytics and no update checks. The only network traffic is the scans that
    you start. See PRIVACY.txt.
  - The interface is only reachable from your own computer (127.0.0.1). Requests
    from other websites are refused.
  - Targets are checked and passed straight to nmap, never through a shell, so
    they can't be turned into extra nmap options or commands.
  - Scan history (IP addresses, MAC addresses, hostnames, open ports) is stored
    in your home folder in ~/.local/share/nmap-gui/. Delete it at any time.

FOR DEVELOPERS
--------------

nmap-gui is plain Python (standard library only), HTML, CSS and JavaScript, with
no build step.

  - server.py: Local web server: runs nmap, reads its XML, compares scans, saves
    history
  - static/index.html, app.css: Page layout and design (light/dark)
  - static/app.js: Scans, results, map, history
  - static/compare.js: Changes tab and email note
  - tests/: End-to-end test (scans 127.0.0.1 only) and comparison tests
  - check.sh: Runs all tests
  - install.sh, uninstall.sh: Per-user install with app menu entry
  - packaging/: Desktop entry, AppStream metadata, icons, RPM spec and build-
    rpm.sh
  - tools/export_text.py: Makes README.txt and nmap-gui-source.txt

Run the tests with ./check.sh, and build the RPM with ./packaging/build-rpm.sh.

LICENCE
-------

nmap-gui is free software: you can redistribute it and/or modify it under the
terms of the GNU General Public License, version 3 or (at your option) any later
version. It is a copyleft licence: if you share a changed version, you must
share its source code under the same licence. See LICENSE.

nmap-gui does not include nmap. It runs the nmap program installed on your
computer, which has its own licence (the Nmap Public Source License). nmap-gui
is an independent project and is not affiliated with or endorsed by the Nmap
Project. Nmap is a trademark of Nmap Software LLC.

(Plain-text version of README.md, made by tools/export_text.py.)
